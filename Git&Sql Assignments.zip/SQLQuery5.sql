create database assignment2

CREATE TABLE [dbo]. [Employee](
[Empid] [Int] IDENTITY (1, 1) NOT NULL Primary key,
[EmpNumber] [nvarchar](50) NOT NULL,
[EmpFirstName] [nvarchar](150) NOT NULL,
[EmpLastName] [nvarchar](150) NULL,
[EmpEmail] [nvarchar](150) NULL,
[Managerid] [int] NULL,
[Departmentid] [INT]
)

CREATE TABLE [dbo].[Department](
[Departmenttid] [int] IDENTITY (1, 1) NOT NULL primary key,
[DepartmentName] [nvarchar](255) NOT NULL
)
insert into Employee
(EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)
values('A001','Samir','Singh','samir@abc.com',2,2)
insert into Employee
(EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)
values('A002','Amit','Kumar','amit@abc.com',1,1)
insert into Employee (EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)
values('A003','Neha','Sharma','neha@abc.com',1,2)
insert into Employee (EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)
values('A004','Vivek','Kumar','vivek@abc.com',1,NULL)

insert into Department(DepartmentName)
values('Accounts')
insert into Department(DepartmentName)
values('Admin')
insert into Department(DepartmentName)
values('HR')
insert into Department(DepartmentName)
values('Technology')

/*Query for Inner Join*/
SELECT Emp.Empid, Emp.EmpFirstName, Emp.EmpLastName, Dept.DepartmentName 
 FROM Employee Emp 
  INNER JOIN Department dept 
     ON Emp.Departmentid=Dept.Departmenttid

	/* Query for the Self Join*/
SELECT Emp1.Empid, 
       Emp1.EmpFirstName+' '+Emp1.EmpLastName as EmployeeName, 
    Emp2.EmpFirstName+' '+Emp2.EmpLastName as ManagerName 
  FROM Employee Emp1 
     INNER JOIN Employee Emp2 
    ON Emp1.Managerid=Emp2.Empid

	/*Query for Left Outer Join*/
	SELECT Emp.Empid, 
       Emp.EmpFirstName, 
    Emp.EmpLastName, 
    Dept.DepartmentName
  FROM Employee Emp 
     LEFT OUTER JOIN Department dept 
     ON Emp.Departmentid=Dept.Departmenttid

	 /*Query for Right Outer Join*/
	 SELECT Dept.DepartmentName, 
       Emp.Empid, Emp.EmpFirstName, 
    Emp.EmpLastName 
  FROM Employee Emp 
    RIGHT OUTER JOIN Department dept 
   ON Emp.Departmentid=Dept.Departmenttid

   /*Query for Full Outer Join*/
   SELECT Emp.Empid, 
       Emp.EmpFirstName, 
    Emp.EmpLastName, 
    Dept.DepartmentName 
  FROM Employee Emp 
     FULL OUTER JOIN Department dept 
    ON Emp.Departmentid=Dept.Departmenttid

	/*Query for the Cross Join*/
	SELECT Emp.Empid,
       Emp.EmpFirstName,
       Emp.EmpLastName,
    Dept.DepartmentName 
 FROM Employee Emp 
   CROSS JOIN Department dept

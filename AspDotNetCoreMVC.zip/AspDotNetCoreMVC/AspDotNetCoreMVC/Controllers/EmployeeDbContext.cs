﻿using AspcoreCurdoperations.Models;

namespace AspcoreCurdoperations.Controllers
{
    internal class EmployeeDbContext
    {
        internal readonly IEnumerable<Employee> employee;
    }
}
﻿using Microsoft.AspNetCore.Mvc;

namespace AspDotNetCoreMVC.Controllers
{
    public class HomeController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{

    class StackException : Exception
    {
        public StackException(String Message) : base(Message)
        {

        }
    }
    public class Validate
    {
        public static void V1()
        {
            Stack<int> objStack = new Stack<int>();
            objStack.Push(1);
            objStack.Push(2);
            objStack.Push(3); // Display first value from Stack
            Console.WriteLine("{0},{1},{2}", objStack.Pop(), objStack.Pop(), objStack.Pop());
            if (objStack.Count() == 0)
            {
                throw new StackException("Stack is Emty");
            }
        }
    }
    public class CustomStackException
    {
        public static void Main(string[] args)
        {
            try
            {
                Validate.V1();
            }
            catch (StackException cse)
            {
                Console.WriteLine(cse.Message);
            }
            Console.ReadKey();
        }
    }


}

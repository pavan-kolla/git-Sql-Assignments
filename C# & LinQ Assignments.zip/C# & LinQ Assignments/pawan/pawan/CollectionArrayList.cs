﻿using System;
using System.Collections;

namespace pawan
{
    internal class CollectionArrayList
    {
        public static void Main()
        {
            ArrayList al = new ArrayList();
            al.Add("pawan");
            al.Add("surya");
            al.Add("rakesh");
            al.Add("vamsi");
            al.Add("bharath");
            al.Add("shankar");
            al.Add("phani");
            al.Add("prasad");
            al.Add(547);
            Console.WriteLine(al.Capacity);

            foreach (object o in al)
            {
                Console.WriteLine(o);

            }

            Console.ReadKey();
        }
    }
}

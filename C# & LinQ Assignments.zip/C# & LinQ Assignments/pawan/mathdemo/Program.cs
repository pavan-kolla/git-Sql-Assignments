﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mathdemo
{
        internal class Program
        {
            static void Main(string[] args)
            {

                void cube()
                {
                    int num, result;
                    Console.Write("Enter the Number : ");
                    num = Convert.ToInt32(Console.ReadLine());
                    result = num * num * num;
                    Console.Write("Cube of number is : " + result);

                }
                cube();
                Console.ReadKey();

            }

        }
    }

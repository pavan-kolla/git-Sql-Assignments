﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace AdoCrudOperations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con;



            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);
            con.Open();
            Console.WriteLine("Connection Is Established");
            try
            {
                char say;
                do
                {



                    Console.WriteLine("Choose Your Choice : \n 1.Insertion \n 2.Retrive \n 3.Update \n 4.delete");
                    int Choice = int.Parse(Console.ReadLine());



                    switch (Choice)
                    {
                        case 1:



                            Console.WriteLine("Enter Employee Id:");
                            int empid = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Employee Number:");
                            string empnumber = Console.ReadLine();
                            Console.WriteLine("Enter Employee First Name:");
                            string empfirstname = Console.ReadLine();
                            Console.WriteLine("Enter Employee Last Name:");
                            string emplastname = Console.ReadLine();
                            Console.WriteLine("Enter Employee Email:");
                            string empemail = Console.ReadLine();
                            Console.WriteLine("Enter Employee Manager Id:");
                            int managerid = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Employee Departent Id:");
                            int departmentid = int.Parse(Console.ReadLine());
                            string insertqery = "INSERT INTO Employee(Empid,EmpNumber,EmpFirstName,EmpLastName,EmpEmail) VALUES (" + empid + ",'" + empnumber + "','" + empfirstname + "','" + emplastname + "','" + empemail + "') ";
                            SqlCommand insertcomm = new SqlCommand(insertqery, con);
                            insertcomm.ExecuteNonQuery();
                            Console.WriteLine("data is Successfully inserted into a table");
                            break;
                        case 2:
                            string retrive = "select *from Employee";
                            SqlCommand retrivecomm = new SqlCommand(retrive, con);
                            SqlDataReader empdata = retrivecomm.ExecuteReader();
                            while (empdata.Read())
                            {
                                int emid = Convert.ToInt32(empdata["Empid"]);
                                string emnumber = Convert.ToString(empdata["EmpNumber"]);
                                string emfirstname = Convert.ToString(empdata["EmpFirstName"]);
                                string emlastname = Convert.ToString(empdata["EmpLastName"]);
                                string ememail = Convert.ToString(empdata["EmpEmail"]);
                                string emmanagerid = Convert.ToString(empdata["Managerid"]);
                                string emdepartmentid = Convert.ToString(empdata["Departmentid"]);
                                Console.WriteLine(emid + " " + emnumber + " " + emfirstname + " " + emlastname + " " + ememail + " " + emmanagerid + " " + emdepartmentid);




                            }
                            empdata.Close();
                            break;



                        case 3:
                            Console.WriteLine("Enter Employee Managerid For update :");
                            int U_EM = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter EmpId where you want to Update:");
                            int empidforupdate = int.Parse(Console.ReadLine());
                            string updateqry = "UPDATE Employee SET Managerid = " + U_EM + " WHERE Empid = " + empidforupdate + "";
                            SqlCommand updatecomm = new SqlCommand(updateqry, con);
                            updatecomm.ExecuteNonQuery();
                            Console.WriteLine("Data is Sucessfully Inserted in to a table :");
                            break;
                        case 4:
                            Console.WriteLine("Enter Employeeid for delete particlar row :");
                            int empidfordelete = int.Parse(Console.ReadLine());
                            string deletequry = "DELETE FROM Employee where Empid=" + empidfordelete + "";
                            SqlCommand deletecomm = new SqlCommand(deletequry, con);
                            deletecomm.ExecuteNonQuery();
                            Console.WriteLine("Data is Sucessfully delete in a table");
                            break;



                        default:
                            Console.WriteLine("Invalid Input :");
                            break;




                    }
                    Console.WriteLine("Do You want to continue:(y/n)");
                    say = Convert.ToChar(Console.ReadLine());



                } while (say == 'y');



            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                con.Close();



            }
            Console.ReadKey();
        }
    }
}
